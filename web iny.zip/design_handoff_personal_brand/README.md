# Handoff: Personal Brand Design System

## Overview

A warm, editorial-style design system for a personal-brand / portfolio site. Built around a calm cream-toned base with a single accent color, big bold grotesk typography (Geist), italic serif accents (Instrument Serif), and signature **black → green hover transitions** on cards and buttons. Includes a curated palette library, light/dark mode, and tweakable tokens.

Content is in **Slovak** (sk-SK) but the system itself is language-agnostic.

## About the Design Files

The files in this bundle are **design references created in HTML/CSS/React** — prototypes showing the intended look and behavior, not production code to copy directly. Your task is to **recreate these designs in your target codebase's existing environment** (React, Vue, SvelteKit, SwiftUI, native, etc.) using its established patterns and component libraries. If no environment exists yet, choose the most appropriate framework (Next.js + Tailwind is a sensible default for a portfolio).

Treat `styles.css` and the JSX as a spec — port the **tokens, behavior, and structure**, not the literal classnames.

## Fidelity

**High-fidelity (hifi).** Final colors, typography, spacing, radii, and motion. Recreate pixel-perfectly using your codebase's existing tooling.

---

## Design Tokens

All values are CSS custom properties in `styles.css`. Port them to your tokens system (Tailwind theme, CSS vars, design-tokens.json, etc.).

### Color — light theme (default palette: **butter**)
| Token            | Value                       | Use                              |
|------------------|-----------------------------|----------------------------------|
| `--bg`           | `#f1ead8`                   | Page background                  |
| `--bg-elev`      | `#e7dfca`                   | Cards, surfaces                  |
| `--fg`           | `#1f1d18`                   | Primary text, dark surfaces      |
| `--fg-muted`     | `#6b6553`                   | Secondary text                   |
| `--fg-subtle`    | `#a8a292`                   | Tertiary text                    |
| `--line`         | `rgba(31,29,24,0.10)`       | Hairline dividers                |
| `--line-strong`  | `rgba(31,29,24,0.20)`       | Visible borders                  |
| `--accent`       | `#2a5d3f` (moss green)      | Hover fill, dots, selection      |
| `--accent-ink`   | `#f2eee8`                   | Text on accent                   |
| `--accent-soft`  | `#d6e2d2`                   | Accent tint background           |
| `--blue`         | `#3e5c76`                   | Secondary accent                 |
| `--warn`         | `#c97a3a`                   | Warning / status                 |

### Color — dark theme (`[data-theme="dark"]`)
| Token            | Value                       |
|------------------|-----------------------------|
| `--bg`           | `#14130f`                   |
| `--bg-elev`      | `#1c1b16`                   |
| `--fg`           | `#f2eee8`                   |
| `--fg-muted`     | `#9b948a`                   |
| `--fg-subtle`    | `#5a554e`                   |
| `--line`         | `rgba(242,238,232,0.10)`    |
| `--line-strong`  | `rgba(242,238,232,0.22)`    |
| `--accent`       | `#6fbb87`                   |
| `--accent-ink`   | `#0b1d12`                   |
| `--blue`         | `#8aa9c2`                   |
| `--warn`         | `#e3a06b`                   |

### Palette library (alternative `[bg, bg-elev, fg]` triples for light mode)

| Name          | bg        | bg-elev   | fg        |
|---------------|-----------|-----------|-----------|
| Butter ⭐     | `#f1ead8` | `#e7dfca` | `#1f1d18` |
| Peach cream   | `#f3e4d3` | `#ecd9c2` | `#231a14` |
| Pistachio     | `#e8ecd6` | `#dde2c4` | `#1c2014` |
| Dusty blush   | `#f1e2dc` | `#e8d3cb` | `#241814` |
| Bone          | `#e9e5dc` | `#dcd6c8` | `#1a1916` |
| Latte         | `#e3d9c4` | `#d6c9ae` | `#1f1810` |
| Sage          | `#dde7df` | `#cddccf` | `#10211a` |
| Lavender mist | `#e7e2ee` | `#d9d2e3` | `#1a172a` |
| Sky paper     | `#dde7ee` | `#ccdae5` | `#0f1a24` |
| Honey         | `#f0d8b2` | `#e6c896` | `#251806` |
| Terracotta    | `#edd0c4` | `#e2bcab` | `#2a1610` |
| Mint          | `#d4e4dc` | `#c2d6cc` | `#0c1c16` |
| Rosé          | `#ead7cf` | `#dec1b6` | `#2a1815` |
| Pewter        | `#dad7cd` | `#c8c4b6` | `#161410` |

Pick one as the default — **Butter is the chosen baseline**. Each triple drives `--bg`, `--bg-elev`, `--fg`; muted/subtle/line variants are derived by linearly mixing `fg` toward `bg` (see the `mix()` and `hexA()` helpers in `app.jsx`).

### Typography

- **Sans (UI + headings):** `Geist`, 300/400/500/600/700
- **Mono (eyebrows, meta, labels):** `Geist Mono`, 400/500
- **Serif (italic accents only):** `Instrument Serif`, italic

Load from Google Fonts:
```html
<link href="https://fonts.googleapis.com/css2?family=Geist:wght@300;400;500;600;700&family=Geist+Mono:wght@400;500&family=Instrument+Serif:ital@0;1&display=swap" rel="stylesheet" />
```

#### Type scale

| Role     | Size (px) | Line-height | Letter-spacing | Weight | Notes                                  |
|----------|-----------|-------------|----------------|--------|----------------------------------------|
| Display  | clamp(48,8vw,112) | 0.95 | -0.04em | 500 | Hero. Use Instrument Serif italic for emphasized words. |
| H1       | 32        | 1.10        | -0.02em        | 500    | Section heads                          |
| H2       | 22        | 1.20        | -0.015em       | 500    |                                        |
| Body     | 16        | 1.55        | 0              | 400    |                                        |
| Lead     | 19        | 1.45        | 0              | 400    | Intro paragraphs                       |
| Small    | 13        | 1.50        | 0              | 400    | Captions                               |
| Mono     | 11–12     | 1.40        | 0.06–0.12em    | 400    | UPPERCASE eyebrows, metadata           |

> **Editorial trick:** wrap one or two words in a heading with the serif italic for emphasis (`<em>`). Used liberally throughout — keeps the system feeling warm.

### Spacing scale
`4, 8, 12, 16, 24, 32, 48, 72, 120` px → `--pad-1` … `--pad-9`. Density tweak multiplies vertical section padding by `0.7 / 0.85 / 1`.

### Radius scale
`0, 6, 10, 18, 28, 999` → `--radius-sm`, `--radius-md`, `--radius-lg`, `--radius-pill`. Default card radius `18px`, buttons `999px` (pill).

### Shadows
- `--shadow-sm`: `0 1px 2px rgba(20,19,15,.04), 0 1px 1px rgba(20,19,15,.03)`
- `--shadow-md`: `0 6px 24px -8px rgba(20,19,15,.16), 0 2px 6px rgba(20,19,15,.04)`

### Motion
- Easing: `cubic-bezier(0.2, 0.7, 0.15, 1)` — everywhere
- Durations: `--t-fast: 180ms`, `--t-base: 320ms`, `--t-slow: 520ms`

---

## Components

### 1. Button — three variants, one rhythm

All three share: pill shape, 14.5px label, mono-styled icon, 44px standard height (34 sm / 54 lg).

**Primary** — `bg: --fg` `color: --bg`. On hover, an accent-colored layer (`::before`) slides from `translateY(100%)` to `0` over 320ms. Border switches to accent. Icon translates `(3px, -3px)`.

**Secondary** — transparent with `--line-strong` border. On hover, `--fg`-colored layer slides up the same way; text inverts to `--bg`.

**Ghost** — no fill, no border, padding 0 4px. Text has a 1px underline that retreats from right then reappears from left (keyframe `ghost-underline`).

Always pair label with an up-right arrow icon (`16×16`, stroke 1.4). On hover, icon translates 3px right + 3px up.

```jsx
<Button variant="primary | secondary | ghost" size="sm | md | lg">Label</Button>
```

### 2. Card — black → accent hover

`background: --fg`, `color: --bg`, `padding: 28px`, `min-height: 280px`. `::before` layer holds `--accent` and slides up from below over 520ms on hover. Card itself translates `-4px`. Inner arrow has its own subtle hover state.

Structure (top → bottom):
1. Card number (`mono`, 11px, uppercase, opacity 0.6)
2. Spacer (flex)
3. Title (28px / 500 / -0.02em, max-width 12ch)
4. Body (14px, opacity 0.78, max 36ch)
5. Footer row: "Pozri →" label · 36px round arrow chip

Variants: `tall` (360px min-height), `wide` (grid-column span 2).

### 3. Testimonial card

Cream surface (`--bg-elev`) with `--line` border, 32px padding, 18px radius. Italic Instrument Serif quote (22px). Quote starts with an accent-colored large `"` glyph. Footer: 40px gradient avatar (accent → blue) with initials · name · role (mono).

### 4. Nav — sticky, blurred

44px tall row inside a `max-w 1280` shell. Left: brand mark (22px circle with internal `::after` accent slide-in on hover) + name. Center: live status pill with pulsing accent dot. Right: nav links (pill hover bg, underline on `.active`), theme toggle (`36×36` circle button), small primary CTA.

Backdrop: `blur(12px) saturate(1.4)` over `color-mix(in oklab, --bg 80%, transparent)`.

### 5. Tweaks panel

Floating bottom-right panel exposing:
- Theme (light / dark radio)
- Palette (color swatch picker, 14 options)
- Accent (color swatch, 4 options)
- Radius slider (0–36px)
- Density radio (compact / regular / comfy)

In production you can keep this as an admin/preview tool or drop it entirely once the brand is locked.

---

## Screens / Views (in the reference)

The reference is a **single scrollable design-system page** with these sections, top to bottom:

1. **Nav** — sticky header (see component spec above)
2. **Hero** — meta line · big italic-flavored display heading · lead paragraph · 3-button action row
3. **Color (01)** — section head pattern + 8-swatch grid
4. **Typography (02)** — type-row spec table (mono label left, sample right)
5. **Buttons (03)** — 3 dashed cream blocks, one per variant, each showing sm/md/lg
6. **Cards (04)** — 5-card auto-fit grid with one tall and one wide variant
7. **Recenzie (05)** — 3-up testimonial grid
8. **Tokens (06)** — radius scale row + spacing scale row, both as bordered cells
9. **Footer / CTA** — big italic-flavored question heading + primary/ghost actions + meta column

**Section head pattern** (reused everywhere): two columns on desktop (`220px 1fr`), eyebrow on the left, H-section + lead on the right. Stacks at <760px.

**Eyebrow** = `01 · Sekcia` in mono uppercase, prefixed by a 6px accent dot.

---

## Interactions & Behavior

| Element       | Trigger | Effect                                                                 |
|---------------|---------|------------------------------------------------------------------------|
| Primary btn   | hover   | accent fills from below (320ms ease), arrow shifts up-right            |
| Secondary btn | hover   | fg-color fills from below, text inverts                                |
| Ghost btn     | hover   | underline retreats right then sweeps in from left                      |
| Card          | hover   | accent fills from below (520ms), card lifts -4px, arrow chip shifts    |
| Testimonial   | hover   | subtle lift -3px, border darkens                                       |
| Brand mark    | hover   | inner accent disc slides up to cover circle                            |
| Status dot    | always  | 2.4s pulse (box-shadow ring expands and fades)                         |
| Theme toggle  | click   | flips `data-theme` attribute on `<html>`                               |
| Nav link      | hover   | pill background `--line`, color → `--fg`                               |

Reduced motion: all the slide-up transitions are decorative; respect `prefers-reduced-motion: reduce` by setting transition durations to 0 or fade only.

---

## State Management

For a portfolio site:
- **Theme** — persist in `localStorage` and apply `data-theme` on `<html>` on hydration
- **Active nav section** — driven by `IntersectionObserver` on each section, not click handlers
- Everything else is stateless / CSS-driven

If you keep the Tweaks panel as a live editor, persist the whole tweaks object to `localStorage`.

---

## Implementation Notes

- **Don't ship the Babel + UMD React setup from the reference** — that's only for the design preview. Use your real toolchain.
- **Don't copy `tweaks-panel.jsx`** — it's a tweaking shim, not production UI.
- The reference uses `<em>` for italic-serif emphasis inside headings. Map this to a `<span class="italic-accent">` (or similar) in your codebase so editors can't accidentally drop a `<em>` and lose styling.
- The accent's "ink" color (text on accent) is computed by luminance — see `pickInk()` in `app.jsx`. Either port the helper or just hardcode `--accent-ink` per accent option.
- All breakpoints use simple `@media (max-width: 760px)` rules. There's no formal breakpoint scale; introduce one if your project needs it.

---

## Files in this Bundle

| File              | What it is                                                              |
|-------------------|-------------------------------------------------------------------------|
| `README.md`       | This document — implement from this alone                               |
| `index.html`      | Reference page entry point                                              |
| `styles.css`      | All design-token CSS — **this is your starting point**                  |
| `components.jsx`  | React reference implementations of Button, Nav, Card, Testimonial       |
| `app.jsx`         | Section composition + theme/palette logic + utility helpers             |
| `tweaks-panel.jsx`| Tweak panel scaffold (skip for production)                              |

---

## Assets

- **Fonts**: Geist, Geist Mono, Instrument Serif — all from Google Fonts (free, OFL)
- **Icons**: Inline SVG, defined in `components.jsx` under `Icon.*`. Drop into your icon library or replace with Lucide / Phosphor (look for: arrow-up-right, arrow-right, sun, moon, sparkle).
- **Imagery**: None in the reference — placeholders only. Bring your own photography.
- No proprietary brand assets are used.
