/* global React, ReactDOM, Button, Nav, Card, Testimonial, Swatch, Icon, useTweaks, TweaksPanel, TweakSection, TweakRadio, TweakColor, TweakToggle, TweakSlider */
const { useState, useEffect } = React;

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "theme": "light",
  "accent": "#2a5d3f",
  "radius": 18,
  "density": "comfy",
  "palette": ["#f1ead8", "#e7dfca", "#1f1d18"]
}/*EDITMODE-END*/;

const ACCENT_OPTIONS = [
  "#2a5d3f", // moss green (default)
  "#3e5c76", // muted blue
  "#c97a3a", // burnt orange
  "#7a4f9f", // plum
];

// [bg, bg-elev, fg] — curated warm light palettes
const PALETTE_OPTIONS = [
  ["#f1ead8", "#e7dfca", "#1f1d18"], // butter
  ["#f3e4d3", "#ecd9c2", "#231a14"], // peach cream
  ["#e8ecd6", "#dde2c4", "#1c2014"], // pistachio
  ["#f1e2dc", "#e8d3cb", "#241814"], // dusty blush
  ["#e9e5dc", "#dcd6c8", "#1a1916"], // bone
  ["#e3d9c4", "#d6c9ae", "#1f1810"], // latte (deeper cream)
  ["#dde7df", "#cddccf", "#10211a"], // sage
  ["#e7e2ee", "#d9d2e3", "#1a172a"], // lavender mist
  ["#dde7ee", "#ccdae5", "#0f1a24"], // sky paper
  ["#f0d8b2", "#e6c896", "#251806"], // honey
  ["#edd0c4", "#e2bcab", "#2a1610"], // terracotta
  ["#d4e4dc", "#c2d6cc", "#0c1c16"], // mint
  ["#ead7cf", "#dec1b6", "#2a1815"], // rosé
  ["#dad7cd", "#c8c4b6", "#161410"], // pewter (cool neutral)
];

function App() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  // Apply theme + tokens to <html>
  useEffect(() => {
    const root = document.documentElement;
    root.setAttribute("data-theme", t.theme);
    root.style.setProperty("--accent", t.accent);
    // pick a readable ink color for the accent
    const ink = pickInk(t.accent);
    root.style.setProperty("--accent-ink", ink);
    root.style.setProperty("--radius-lg", `${t.radius}px`);
    root.style.setProperty("--radius-md", `${Math.max(4, Math.round(t.radius * 0.55))}px`);
    root.style.setProperty(
      "--density",
      t.density === "compact" ? "0.7" : t.density === "regular" ? "0.85" : "1"
    );

    // Apply palette only in light mode; dark mode keeps its own scheme
    if (t.theme === "light" && Array.isArray(t.palette)) {
      const [bg, elev, fg] = t.palette;
      root.style.setProperty("--bg", bg);
      root.style.setProperty("--bg-elev", elev);
      root.style.setProperty("--fg", fg);
      root.style.setProperty("--fg-muted", mix(fg, bg, 0.55));
      root.style.setProperty("--fg-subtle", mix(fg, bg, 0.78));
      root.style.setProperty("--line", hexA(fg, 0.10));
      root.style.setProperty("--line-strong", hexA(fg, 0.20));
    } else {
      // clear inline overrides so the [data-theme] sheet takes over again
      ["--bg","--bg-elev","--fg","--fg-muted","--fg-subtle","--line","--line-strong"]
        .forEach((k) => root.style.removeProperty(k));
    }
  }, [t]);

  return (
    <div>
      <Nav theme={t.theme} setTheme={(v) => setTweak("theme", v)} />

      {/* HERO */}
      <header className="shell hero" id="system">
        <div className="hero-meta">
          <span>Bratislava · Remote</span>
          <span>Brand · Web · Produkt</span>
          <span>Od 2018</span>
        </div>
        <h1 className="h-display">
          Návrhy, ktoré <em>počúvajú</em><br />
          a robia vlnu.
        </h1>
        <p className="lead">
          Som Adam — pomáham značkám nájsť tón, formu a tempo. Toto je živý systém, podľa ktorého
          pracujem: typografia, farba, pohyb, a komponenty, ktoré sa správajú ako majú.
        </p>
        <div className="hero-actions">
          <Button variant="primary" size="lg">Pozri portfólio</Button>
          <Button variant="secondary" size="lg">Stiahni CV</Button>
          <Button variant="ghost" size="lg">Sleduj na LinkedIne</Button>
        </div>
      </header>

      {/* COLOR */}
      <section className="section shell">
        <div className="section-head">
          <div>
            <div className="eyebrow">01 · Farba</div>
          </div>
          <div className="stack-3">
            <h2 className="h-section">Tichá paleta s <em>jedným hlasom</em>.</h2>
            <p className="lead">
              Krémové pozadie, hlboká uhľová a jedna akcentová — väčšinou zelená.
              Stačí to na hierarchiu, neutiahne to obsah.
            </p>
          </div>
        </div>

        <div className="swatch-grid">
          <Swatch name="Background" varName="--bg" value="#F2EEE8 / #14130F" />
          <Swatch name="Elevated" varName="--bg-elev" value="surface-1" />
          <Swatch name="Foreground" varName="--fg" value="#1A1A1A" />
          <Swatch name="Foreground muted" varName="--fg-muted" value="#6B665E" />
          <Swatch name="Accent" varName="--accent" value="tweakable" />
          <Swatch name="Accent soft" varName="--accent-soft" value="tint" />
          <Swatch name="Blue" varName="--blue" value="#3E5C76" />
          <Swatch name="Warn" varName="--warn" value="#C97A3A" />
        </div>
      </section>

      {/* TYPE */}
      <section className="section shell" id="type">
        <div className="section-head">
          <div>
            <div className="eyebrow">02 · Typografia</div>
          </div>
          <div className="stack-3">
            <h2 className="h-section">Geist pre&nbsp;hlas, <em>Instrument Serif</em> pre&nbsp;dôraz.</h2>
            <p className="lead">
              Moderný grotesk drží štruktúru, kurzívny serif pridáva osobnosť tam, kde to dáva zmysel — v nadpisoch a citátoch.
            </p>
          </div>
        </div>

        <div>
          <div className="type-row">
            <div className="type-spec">Display · 72/95</div>
            <div className="type-sample t-d1">Tichá <em style={{fontFamily:"var(--font-serif)",fontStyle:"italic",fontWeight:400}}>sila</em></div>
          </div>
          <div className="type-row">
            <div className="type-spec">Heading 1 · 32/110</div>
            <div className="type-sample t-h1">Stručne, ostro, k veci.</div>
          </div>
          <div className="type-row">
            <div className="type-spec">Heading 2 · 22/120</div>
            <div className="type-sample t-h2">Sekcie, ktoré vedia, čo robia.</div>
          </div>
          <div className="type-row">
            <div className="type-spec">Body · 16/155</div>
            <div className="type-sample t-body">
              Text píšem ako keby som ho hovoril nahlas. Krátko, jasne, bez balastu — pretože dobrý dizajn
              nepotrebuje vysvetľovať, čo vidíš.
            </div>
          </div>
          <div className="type-row">
            <div className="type-spec">Small · 13/150</div>
            <div className="type-sample t-small">
              Drobné poznámky, popisky a meta. Vždy v tlmenom tóne, nikdy nekričia.
            </div>
          </div>
          <div className="type-row">
            <div className="type-spec">Mono · 12</div>
            <div className="type-sample t-mono">labels · ratios · token-names</div>
          </div>
        </div>
      </section>

      {/* BUTTONS */}
      <section className="section shell" id="buttons">
        <div className="section-head">
          <div>
            <div className="eyebrow">03 · Tlačidlá</div>
          </div>
          <div className="stack-3">
            <h2 className="h-section">Tri tvary, jeden <em>rytmus</em>.</h2>
            <p className="lead">
              Primary nesie hlavnú akciu. Secondary podporuje. Ghost prepája v texte. Všetky tri majú
              rovnaký prechod — zdola sa nasunie akcent, šípka odskočí.
            </p>
          </div>
        </div>

        <div style={{ display: "grid", gap: 16, gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))" }}>
          <div className="btn-block">
            <span className="btn-block-label">Primary · hlavná akcia</span>
            <div className="btn-row">
              <Button variant="primary" size="sm">Drobné</Button>
              <Button variant="primary">Štandard</Button>
              <Button variant="primary" size="lg">Veľké</Button>
            </div>
            <div className="mono">hover · čierna → akcent zdola</div>
          </div>

          <div className="btn-block">
            <span className="btn-block-label">Secondary · podporná</span>
            <div className="btn-row">
              <Button variant="secondary" size="sm">Drobné</Button>
              <Button variant="secondary">Štandard</Button>
              <Button variant="secondary" size="lg">Veľké</Button>
            </div>
            <div className="mono">hover · obrys sa zaplní</div>
          </div>

          <div className="btn-block">
            <span className="btn-block-label">Ghost · inline</span>
            <div className="btn-row">
              <Button variant="ghost" size="sm">Viac</Button>
              <Button variant="ghost">Čítaj prípadovku</Button>
              <Button variant="ghost" size="lg">Ozvi sa</Button>
            </div>
            <div className="mono">hover · podčiarknutie skočí cez koniec</div>
          </div>
        </div>
      </section>

      {/* CARDS */}
      <section className="section shell" id="cards">
        <div className="section-head">
          <div>
            <div className="eyebrow">04 · Karty</div>
          </div>
          <div className="stack-3">
            <h2 className="h-section">Začnú <em>tmavo</em>, ožijú farbou.</h2>
            <p className="lead">
              Pokojné v sieti, živé pri kontakte. Hover spustí farebnú vlnu zdola, šípka odbočí
              šikmo hore. Funguje aj s klávesnicou.
            </p>
          </div>
        </div>

        <div className="cards-grid">
          <Card num="01"
                title="Brand systém pre Listora"
                body="Identita, voice, typografická hierarchia a 40+ komponentov pre fintech zameraný na šetrenie." />
          <Card num="02" tall
                title="Onboarding pre Mosaic Health"
                body="Štyri kroky, nula trenia. Onboarding, ktorý sa neopýta dvakrát to isté." />
          <Card num="03"
                title="Webová stránka Hlina&nbsp;Studio"
                body="Editoriálny layout, vlastné fotografie, mikro-animácie." />
          <Card num="04"
                title="Mobilná aplikácia Trail"
                body="Komunitná appka pre outdoor — mapy, pozvánky, denník trás." />
          <Card num="05" wide
                title="Rebranding Severná pekáreň"
                body="Od identity po obaly, menu a digitálne kanály. Tri mestá, jedna chuť, konzistentný tón." />
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="section shell">
        <div className="section-head">
          <div>
            <div className="eyebrow">05 · Recenzie</div>
          </div>
          <div className="stack-3">
            <h2 className="h-section">Čo o&nbsp;mne <em>hovoria</em> ľudia, s&nbsp;ktorými som robil.</h2>
          </div>
        </div>

        <div style={{ display: "grid", gap: 12, gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))" }}>
          <Testimonial
            quote="Adam vie počúvať a potom dodať presne to, čo sme nevedeli pomenovať. Ušetril nám tri mesiace ladenia."
            name="Lenka Murínová" role="Co-founder, Listora" initials="LM" />
          <Testimonial
            quote="Najlepšie investovaný čas tohto roka. Brand sa stal nielen krajším, ale zrozumiteľnejším."
            name="Tomáš Vrbický" role="CEO, Hlina Studio" initials="TV" />
          <Testimonial
            quote="Pracuje rýchlo, ale nikdy povrchne. Vždy príde s druhou vrstvou otázok, ktorá nás posunie."
            name="Marek Šimek" role="Head of Product, Mosaic" initials="MŠ" />
        </div>
      </section>

      {/* TOKENS — RADIUS + DENSITY */}
      <section className="section shell">
        <div className="section-head">
          <div>
            <div className="eyebrow">06 · Tokeny</div>
          </div>
          <div className="stack-3">
            <h2 className="h-section">Spacing &amp; <em>radius</em>.</h2>
            <p className="lead">Šesťstupňová škála plochy a päť polomerov — od ostrého rohu po pill.</p>
          </div>
        </div>

        <div className="stack-5">
          <div className="token-list">
            {[
              { n: "r-0", v: "0px", cls: "radius-r0" },
              { n: "r-sm", v: "6px", cls: "radius-r1" },
              { n: "r-md", v: "10px", cls: "radius-r2" },
              { n: "r-lg", v: "18px", cls: "radius-r3" },
              { n: "r-xl", v: "28px", cls: "radius-r4" },
              { n: "r-pill", v: "999px", cls: "radius-r5" },
            ].map((r) => (
              <div className="token-cell" key={r.n}>
                <div className={`token-vis ${r.cls}`}></div>
                <div>
                  <div className="token-name">{r.n}</div>
                  <div className="token-val">{r.v}</div>
                </div>
              </div>
            ))}
          </div>

          <div className="token-list" style={{ gridTemplateColumns: "repeat(auto-fit, minmax(120px, 1fr))" }}>
            {[
              { n: "pad-2", v: "8px", h: 8 },
              { n: "pad-3", v: "12px", h: 12 },
              { n: "pad-4", v: "16px", h: 16 },
              { n: "pad-5", v: "24px", h: 24 },
              { n: "pad-6", v: "32px", h: 32 },
              { n: "pad-7", v: "48px", h: 48 },
              { n: "pad-8", v: "72px", h: 72 },
            ].map((s) => (
              <div className="token-cell" key={s.n}>
                <div style={{ background: "var(--accent)", height: s.h, opacity: 0.85, borderRadius: 2 }}></div>
                <div>
                  <div className="token-name">{s.n}</div>
                  <div className="token-val">{s.v}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FOOTER / CTA */}
      <footer className="shell footer" id="kontakt">
        <div>
          <h2 className="footer-big">
            Robíme niečo<br />
            <em>spolu</em>?
          </h2>
          <div className="hero-actions" style={{ marginTop: 24 }}>
            <Button variant="primary" size="lg">adam@studio.sk</Button>
            <Button variant="ghost" size="lg">LinkedIn</Button>
          </div>
        </div>
        <div className="footer-meta">
          <span>Adam Novák · 2024 → ∞</span>
          <span>Bratislava · CET</span>
          <span>Verzia systému 0.4 alpha</span>
        </div>
      </footer>

      {/* TWEAKS PANEL */}
      <TweaksPanel title="Tweaks">
        <TweakSection label="Téma" />
        <TweakRadio
          label="Mode"
          value={t.theme}
          options={["light", "dark"]}
          onChange={(v) => setTweak("theme", v)}
        />

        <TweakSection label="Pozadie (light)" />
        <TweakColor
          label="Paleta"
          value={t.palette}
          options={PALETTE_OPTIONS}
          onChange={(v) => setTweak("palette", v)}
        />

        <TweakSection label="Akcent" />
        <TweakColor
          label="Farba"
          value={t.accent}
          options={ACCENT_OPTIONS}
          onChange={(v) => setTweak("accent", v)}
        />

        <TweakSection label="Tvar &amp; rytmus" />
        <TweakSlider
          label="Polomer kariet"
          value={t.radius}
          min={0} max={36} step={2} unit="px"
          onChange={(v) => setTweak("radius", v)}
        />
        <TweakRadio
          label="Hustota"
          value={t.density}
          options={["compact", "regular", "comfy"]}
          onChange={(v) => setTweak("density", v)}
        />
      </TweaksPanel>
    </div>
  );
}

// pick black or white-ish ink to contrast against an accent
function pickInk(hex) {
  if (!hex || hex[0] !== "#") return "#f2eee8";
  const h = hex.length === 4
    ? hex.slice(1).split("").map((c) => c + c).join("")
    : hex.slice(1);
  const r = parseInt(h.slice(0, 2), 16);
  const g = parseInt(h.slice(2, 4), 16);
  const b = parseInt(h.slice(4, 6), 16);
  // relative luminance
  const L = (0.2126 * r + 0.7152 * g + 0.0722 * b) / 255;
  return L > 0.55 ? "#14130f" : "#f2eee8";
}

// linear-mix two hex colors (a toward b by amount t ∈ [0,1])
function mix(a, b, amt) {
  const pa = parseHex(a), pb = parseHex(b);
  const r = Math.round(pa[0] + (pb[0] - pa[0]) * amt);
  const g = Math.round(pa[1] + (pb[1] - pa[1]) * amt);
  const bl = Math.round(pa[2] + (pb[2] - pa[2]) * amt);
  return `rgb(${r}, ${g}, ${bl})`;
}
function hexA(hex, a) {
  const [r, g, b] = parseHex(hex);
  return `rgba(${r}, ${g}, ${b}, ${a})`;
}
function parseHex(hex) {
  const h = hex.length === 4
    ? hex.slice(1).split("").map((c) => c + c).join("")
    : hex.slice(1);
  return [parseInt(h.slice(0,2),16), parseInt(h.slice(2,4),16), parseInt(h.slice(4,6),16)];
}

ReactDOM.createRoot(document.getElementById("root")).render(<App />);
