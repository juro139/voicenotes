/* global React */
const { useState, useEffect, useRef } = React;

// ───────────── ICONS ─────────────
const Icon = {
  arrowUR: (p) => (
    <svg {...p} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M4 12L12 4M12 4H5.5M12 4V10.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  arrowR: (p) => (
    <svg {...p} viewBox="0 0 16 16" fill="none" xmlns="http://www.w3.org/2000/svg">
      <path d="M3 8H13M13 8L8.5 3.5M13 8L8.5 12.5" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  ),
  sun: (p) => (
    <svg {...p} viewBox="0 0 16 16" fill="none">
      <circle cx="8" cy="8" r="3" stroke="currentColor" strokeWidth="1.3"/>
      <path d="M8 1.5v1.8M8 12.7v1.8M14.5 8h-1.8M3.3 8H1.5M12.6 3.4l-1.3 1.3M4.7 11.3l-1.3 1.3M12.6 12.6l-1.3-1.3M4.7 4.7L3.4 3.4" stroke="currentColor" strokeWidth="1.3" strokeLinecap="round"/>
    </svg>
  ),
  moon: (p) => (
    <svg {...p} viewBox="0 0 16 16" fill="none">
      <path d="M13.5 9.6A5.6 5.6 0 0 1 6.4 2.5a5.6 5.6 0 1 0 7.1 7.1Z" stroke="currentColor" strokeWidth="1.3" strokeLinejoin="round"/>
    </svg>
  ),
  spark: (p) => (
    <svg {...p} viewBox="0 0 16 16" fill="none">
      <path d="M8 1.5l1.6 4.9L14.5 8l-4.9 1.6L8 14.5l-1.6-4.9L1.5 8l4.9-1.6L8 1.5Z" fill="currentColor"/>
    </svg>
  ),
};

// ───────────── BUTTON ─────────────
function Button({ variant = "primary", size = "md", children, icon = true, onClick }) {
  const cls = `btn btn-${variant} ${size === "sm" ? "btn-sm" : size === "lg" ? "btn-lg" : ""}`;
  return (
    <button className={cls} onClick={onClick}>
      {variant === "ghost" ? (
        <span className="btn-underline">{children}</span>
      ) : (
        <span>{children}</span>
      )}
      {icon && <span className="btn-icon">{Icon.arrowUR({ width: 14, height: 14 })}</span>}
    </button>
  );
}

// ───────────── NAV ─────────────
function Nav({ theme, setTheme }) {
  const [active, setActive] = useState("system");
  const links = [
    { id: "system", label: "Systém" },
    { id: "buttons", label: "Tlačidlá" },
    { id: "cards", label: "Karty" },
    { id: "type", label: "Typo" },
    { id: "kontakt", label: "Kontakt" },
  ];
  return (
    <nav className="nav">
      <div className="nav-inner">
        <a href="#" className="nav-brand" onClick={(e) => e.preventDefault()}>
          <span className="nav-brand-mark"></span>
          <span>Adam Novák</span>
        </a>
        <div className="nav-status">
          <span className="dot"></span>
          Voľný od júna
        </div>
        <div className="nav-links">
          {links.map((l) => (
            <a
              key={l.id}
              href={`#${l.id}`}
              className={`nav-link ${active === l.id ? "active" : ""}`}
              onClick={(e) => { setActive(l.id); }}
            >
              {l.label}
            </a>
          ))}
        </div>
        <button
          className="theme-toggle"
          onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
          aria-label="Prepnúť tému"
        >
          {theme === "dark" ? Icon.sun({}) : Icon.moon({})}
        </button>
        <div className="nav-cta">
          <Button variant="primary" size="sm">Napíš mi</Button>
        </div>
      </div>
    </nav>
  );
}

// ───────────── CARD ─────────────
function Card({ num, title, body, tall, wide }) {
  return (
    <article className={`card ${tall ? "card-tall" : ""} ${wide ? "card-wide" : ""}`}>
      <div>
        <div className="card-num">{num}</div>
      </div>
      <div>
        <h3 className="card-title">{title}</h3>
        <p className="card-body">{body}</p>
        <div className="card-foot">
          <span className="mono" style={{ color: "inherit", opacity: 0.6 }}>Pozri →</span>
          <span className="card-arrow">{Icon.arrowUR({ width: 14, height: 14 })}</span>
        </div>
      </div>
    </article>
  );
}

// ───────────── TESTIMONIAL ─────────────
function Testimonial({ quote, name, role, initials }) {
  return (
    <figure className="tcard">
      <blockquote className="tcard-quote">{quote}</blockquote>
      <figcaption className="tcard-foot">
        <span className="tcard-avatar">{initials}</span>
        <div className="tcard-meta">
          <span className="tcard-name">{name}</span>
          <span className="tcard-role">{role}</span>
        </div>
      </figcaption>
    </figure>
  );
}

// ───────────── SWATCH ─────────────
function Swatch({ name, varName, value }) {
  return (
    <div className="swatch">
      <div className="swatch-chip" style={{ background: `var(${varName})` }}></div>
      <div className="swatch-meta">
        <span className="swatch-name">{name}</span>
        <span className="swatch-val">{value}</span>
      </div>
    </div>
  );
}

// Export to window
Object.assign(window, { Button, Nav, Card, Testimonial, Swatch, Icon });
